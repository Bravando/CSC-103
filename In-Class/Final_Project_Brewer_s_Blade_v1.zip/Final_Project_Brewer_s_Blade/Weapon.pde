class Weapon{
  
}
