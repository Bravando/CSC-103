class Slider {

  PVector posn = new PVector(0, 0), size = new PVector(50, 50);
  Boolean isMovingDownRight, isMovingVertical;
  float speed = 5;
  color c;
  
  Slider(PVector posn, String dir, PVector size, color c, float speed) {
    processDir(dir);
    this.posn = posn;
    this.c = c;
    this.speed = speed;
    this.size = size;
  }
  Slider(PVector posn, String dir, color c, float speed) {
    processDir(dir);
    this.posn = posn;
    this.c = c;
    this.speed = speed;
  }
  Slider(PVector posn, String dir, color c) {
    processDir(dir);
    this.posn = posn;
    this.c = c;
  }
  Slider(float posn, char dir) {
    processDir(dir);
    posnAtEdge(posn);
    c = randomColor();
  }
  Slider(char dir, float size) {
    processDir(dir);
    randomPosn();
    c = randomColor();
    this.size.x = size;
    this.size.y = size;
  }
  Slider(char dir) {
    processDir(dir);
    randomPosn();
    c = randomColor();
  }
  Slider() {
    randomDir();
    randomPosn();
    c = randomColor();
  }
  //     Functions for Initialization
  void processDir(char dir) {
    if (isAcceptableKey(dir)) {
      if (dir == 'a' || dir == LEFT || dir == 'A') {
        isMovingDownRight = false;
        isMovingVertical = false;
      } else if (dir == 'd' || dir == RIGHT || dir == 'D') {
        isMovingDownRight = true;
        isMovingVertical = false;
      } else if (dir == 'w' || dir == UP || dir == 'W') {
        isMovingDownRight = false;
        isMovingVertical = true;
      } else {
        isMovingDownRight = true;
        isMovingVertical = true;
      }
    } else {
      randomDir();
    }
  }
  void processDir(String dir) {
    if (dir == "left") {
      isMovingDownRight = false;
      isMovingVertical = false;
    } else if (dir == "right") {
      isMovingDownRight = true;
      isMovingVertical = false;
    } else if (dir == "up") {
      isMovingDownRight = false;
      isMovingVertical = true;
    } else {
      isMovingDownRight = true;
      isMovingVertical = true;
    }
  }
  void randomDir() {
    Integer dir = int(random(4));
    if (dir == 0) {
      isMovingDownRight = false;
      isMovingVertical = false;
    } else if (dir == 1) {
      isMovingDownRight = true;
      isMovingVertical = false;
    } else if (dir == 2) {
      isMovingDownRight = false;
      isMovingVertical = true;
    } else {
      isMovingDownRight = true;
      isMovingVertical = true;
    }
  }
  void randomPosn() {
    if (isMovingVertical) {
      this.posn.x = random(width);
      if (isMovingDownRight) {
        this.posn.y = 0;
      } else {
        this.posn.y = height;
      }
    } else {
      this.posn.y = random(height);
      if (isMovingDownRight) {
        this.posn.x = 0;
      } else {
        this.posn.x = width;
      }
    }
  }
  void posnAtEdge(float posn) {
    if (isMovingVertical) {
      this.posn.x = posn;
      if (isMovingDownRight) {
        this.posn.y = 0;
      } else {
        this.posn.y = height;
      }
    } else {
      this.posn.y = posn;
      if (isMovingDownRight) {
        this.posn.x = 0;
      } else {
        this.posn.x = width;
      }
      c = randomColor();
    }
  }
  boolean isAcceptableKey(char dir) {
    return (dir == 'a' || dir == LEFT || dir == 'A' || dir == 'd' || dir == RIGHT || dir == 'D'
      || dir == 'w' || dir == UP || dir == 'W' || dir == 's' || dir == DOWN || dir == 'S');
  }

  //  Movement

  void move() {
    if (isMovingVertical) {
      if (isMovingDownRight) {
        moveDown();
      } else {
        moveUp();
      }
    } else {
      if (isMovingDownRight) {
        moveRight();
      } else {
        moveLeft();
      }
    }
  }
  void moveUp() {
    if (!outOfBounds()) {
      posn.y-=speed;
    }
  }
  void moveDown() {
    if (!outOfBounds()) {
      posn.y+=speed;
    }
  }
  void moveLeft() {
    if (!outOfBounds()) {
      posn.x-=speed;
    }
  }
  void moveRight() {
    if (!outOfBounds()) {
      posn.x+=speed;
    }
  }

  // Rendering

  void render() {
    rectMode(CENTER);
    fill(c);
    rect(posn.x, posn.y, size.x, size.y);
  }
  boolean outOfBounds() {
  return (posn.x+size.x/2<0 || posn.y+size.y/2<0
    || posn.x-size.x/2>width || posn.y-size.y/2>height);
}
}
color randomColor() {
  return color(random(255), random(255), random(255));
}
boolean outOfBounds(PVector posn, PVector size) {
  return (posn.x+size.x/2<0 || posn.y+size.y/2<0
    || posn.x-size.x/2>width || posn.y-size.y/2>height);
}
