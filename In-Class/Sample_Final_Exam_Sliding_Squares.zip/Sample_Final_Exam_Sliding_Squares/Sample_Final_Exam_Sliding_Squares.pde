ArrayList<Slider> sliders = new ArrayList<>();
Boolean erasingOldFrames = true;

void setup() {
  size(600, 400, P2D);
  if (!erasingOldFrames) {
    background(32);
  }
  noStroke();
}

void draw() {
  if (erasingOldFrames) {
    background(32);
  }
  removeOutOfBoundsSliders(sliders);
  renderAndMoveSliders(sliders);
}

void keyPressed() {
  if (key == BACKSPACE) {
    if (!erasingOldFrames) {
      background(32);
    }
    sliders = new ArrayList<>();
  } else if (key == ' ') {
    erasingOldFrames = !erasingOldFrames;
  } else {
    sliders.add(new Slider(key, 30));
  }
}

void removeOutOfBoundsSliders(ArrayList<Slider> sList) {
  for (int i = 0; i<sList.size(); i++) {
    if (sList.get(i).outOfBounds()) {
      sList.remove(i).render();
    }
  }
}
void renderAndMoveSliders(ArrayList<Slider> sList) {
  for (int i = 0; i<sList.size(); i++) {
    sList.get(i).render();
    sList.get(i).move();
  }
}
