interface Renderable {

  void render();

}
void renderAll(Renderable[] items){
  for(int i = 0;i<items.length;i++){
    items[i].render();
  }
}
void renderAll(ArrayList<Renderable> items){
  for(int i = 0;i<items.size();i++){
    items.get(i).render();
  }
}
